﻿(function () {
  "use strict";
  angular
      .module("productManagement")
      .controller("ProductAddCtrl",
                  ["$state", "$stateParams", "$http", "appSettings", ProductAddCtrl]);

  function ProductAddCtrl($state, $stateParams, $http, appSettings) {
    var test = appSettings.serverPath;
    var vm = this;
    vm.product = {};

    vm.submit = function () {

      vm.product.customerId = $stateParams.customerId;

      $http({
        method: "POST",
        url: 'http://localhost:51105/api/product',
        data: vm.product
      })
      .then(function (response) {
        // success
        toastr.success("Product Added");       
        $state.go('productDetail', { customerId: $stateParams.customerId });
      }, function () {
        toastr.error("Error occured please contact help desk");
      });
    }
    vm.cancel = function () {
      $state.go('customerList');
    };
  }
}());
