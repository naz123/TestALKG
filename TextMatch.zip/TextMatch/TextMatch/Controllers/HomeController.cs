﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TextMatch.Models;

namespace TextMatch.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
          Eviivo model = new Eviivo();
          model.Text = "Polly put the kettle on, polly put the kettle on, polly put the kettle on we’ll all have tea";

          return View(model);
        }



        [HttpPost]
        public ActionResult Index(Eviivo model)
        {      
          string result = solution(model.Text, model.Subtext);
          ViewBag.result = result;
          return View();
        }

        private string solution(string text, string subtext)
        {
          text = text.ToUpper();
          subtext = subtext.ToUpper();
          int foundWordPos = -1;
          string outputString = "";
          int i = 0;   
          while (i < text.Length)
          {
            // always match with the first letter
            if (text[i] == subtext[0])
            {
              foundWordPos = i;
              // example found a word starting with p ..is this polly.??
              // to see if this is the word we want we need to check all the letters of polly
              for (int j = 0; j < subtext.Length; j++)
              {
                if (subtext[j] != text[i])
                {
                  //reset found word as not all letters match
                  foundWordPos = -1;
                  i++;
                  break;
                }
                else
                  i++; //letters are matching so far - lets check next letter
                }

              if (foundWordPos != -1)
              {
                //found word so add the position to the output
                outputString += foundWordPos + 1 + ",";
                //reset ready for next find of word
                foundWordPos = -1;
              }
            }
            else
              i++;
          }

          if (string.IsNullOrWhiteSpace(outputString))
            outputString = "There is no output";
            
          return outputString;
        }


    }
}
