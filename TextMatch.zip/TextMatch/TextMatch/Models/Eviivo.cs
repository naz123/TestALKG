﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TextMatch.Models
{
  public class Eviivo
  {
    public string Text { get; set; }
    public string Subtext { get; set; }
  }
}